package pkgnew.practic;

import java.util.List;
import java.util.ArrayList;

public class Menujava {
     private List<MenuItem> items;

    public Menujava() {
        items = new ArrayList<>();
    }

    public void addItem(MenuItem item) {
        items.add(item);
        System.out.println(item.getName() + " has been added to the menu.");
    }

    public void deleteItem(MenuItem item) {
        if (items.remove(item)) {
            System.out.println(item.getName() + " has been removed from the menu.");
        } else {
            System.out.println(item.getName() + " was not found in the menu.");
        }
    }

    public void updateItem(MenuItem oldItem, MenuItem newItem) {
        int index = items.indexOf(oldItem);
        if (index != -1) {
            items.set(index, newItem);
            System.out.println(oldItem.getName() + " has been updated to " + newItem.getName() + ".");
        } else {
            System.out.println(oldItem.getName() + " was not found in the menu.");
        }
    }

    public void displayMenu() {
        System.out.println("Menu Items:");
        for (MenuItem item : items) {
            item.displayDetails();
        }
    }
}
