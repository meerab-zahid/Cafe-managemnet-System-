
package pkgnew.practic;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Vector;
import javax.swing.border.Border;

public class Menu extends JFrame{
 DefaultTableModel tableModel;
    JLabel totalLabel;

    Menu() {
        setTitle("Cafe Management System");
        setSize(2000, 700);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        ImageIcon floralImage = new ImageIcon("C:\\Users\\hp\\Desktop\\practice\\Boarder.jpg"); 
        Border floralBorder = BorderFactory.createMatteBorder(50, 50, 80, 50, floralImage); 
        getRootPane().setBorder(floralBorder); 

        
        JPanel panel1 = new JPanel();
        panel1.setLayout(new GridLayout(4, 1, 10, 10));
        panel1.setPreferredSize(new Dimension(150, 600));
        panel1.setBackground(new Color(255, 182, 193));

        JButton hButton = createButton("Back");
        JButton mButton = createButton("Menu Item Management");
        JButton oButton = createButton("Order Management");
        JButton sButton = createButton("Staff Management");

        hButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dispose();
                new Login();
            }
        });

        sButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dispose();
                new StaffMangement();
            }
        });

        mButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dispose();
                new ItemManagement();
            }
        });

        oButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dispose();
                new Menu();
            }
        });

        panel1.add(hButton);
        panel1.add(mButton);
        panel1.add(sButton);
        panel1.add(oButton);

        add(panel1, BorderLayout.WEST);

        
        JPanel menuPanel = new JPanel();
        menuPanel.setLayout(new GridLayout(3, 3, 10, 10));
        menuPanel.setBackground(new Color(255, 228, 225)); // Soft pink background

        String[][] menuItems = {
                {"Burger", "100.0", "C:\\Users\\hp\\Desktop\\CAfe managemnet\\burger.jpg"},
                {"Spaghetti", "200.0", "C:\\Users\\hp\\Desktop\\CAfe managemnet\\i.jpg"},
                {"Brownie", "150.0", "C:\\Users\\hp\\Desktop\\CAfe managemnet\\Brownie.jpg"},
                {"Drum Stick", "120.5", "C:\\Users\\hp\\Desktop\\CAfe managemnet\\Drum Sticks.jpg"},
                {"Loaded Fries", "90.7", "C:\\Users\\hp\\Desktop\\CAfe managemnet\\LoadedFRies.jpg"},
                {"Cappuccino", "250.3", "C:\\Users\\hp\\Desktop\\CAfe managemnet\\Cappuccino.jpeg"},
                {"Sandwich", "234.5", "C:\\Users\\hp\\Desktop\\CAfe managemnet\\Sand.jpg"},
                {"Juice", "200.5", "C:\\Users\\hp\\Desktop\\CAfe managemnet\\juice.jpg"},
                {"Tea", "210.1", "C:\\Users\\hp\\Desktop\\CAfe managemnet\\Chqay.jpg"}
        };

        for (String[] item : menuItems) {
            JPanel itemPanel = new JPanel();
            itemPanel.setLayout(new BorderLayout());
            itemPanel.setBorder(BorderFactory.createLineBorder(new Color(255, 105, 180))); 
            itemPanel.setBackground(new Color(255, 240, 245));

            JLabel nameLabel = new JLabel(item[0] + " - $" + item[1], JLabel.CENTER);
            nameLabel.setFont(new Font("Arial", Font.BOLD, 14));
            nameLabel.setForeground(new Color(255, 20, 147)); 

            ImageIcon itemImage = new ImageIcon(item[2]);
            Image scaledImage = itemImage.getImage().getScaledInstance(100, 100, Image.SCALE_SMOOTH);
            JLabel imageLabel = new JLabel(new ImageIcon(scaledImage));
            imageLabel.setHorizontalAlignment(JLabel.CENTER);

            JPanel bottomPanel = new JPanel(new FlowLayout());
            bottomPanel.setBackground(new Color(255, 228, 225)); 
            JComboBox<Integer> quantityBox = new JComboBox<>(new Integer[]{0, 1, 2, 3, 4, 5});
            JButton addButton = createButton("Add");

            bottomPanel.add(quantityBox);
            bottomPanel.add(addButton);

            itemPanel.add(nameLabel, BorderLayout.NORTH);
            itemPanel.add(imageLabel, BorderLayout.CENTER);
            itemPanel.add(bottomPanel, BorderLayout.SOUTH);

            menuPanel.add(itemPanel);

            addButton.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    int quantity = (int) quantityBox.getSelectedItem();
                    if (quantity > 0) {
                        double price = Double.parseDouble(item[1]);
                        double totalPrice = quantity * price;
                        tableModel.addRow(new Object[]{item[0], quantity, "$" + totalPrice});
                        updateTotal();
                    }
                }
            });
        }

        add(menuPanel, BorderLayout.CENTER);

        
        JPanel tablePanel = new JPanel();
        tablePanel.setLayout(new BorderLayout());
        tablePanel.setBackground(new Color(255, 228, 225)); 

        tableModel = new DefaultTableModel(new Object[]{"Product Name", "Quantity", "Price"}, 0);
        JTable table = new JTable(tableModel);
        JScrollPane tableScrollPane = new JScrollPane(table);

        JPanel totalPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        totalPanel.setBackground(new Color(255, 182, 193)); 
        totalLabel = new JLabel("Total: 0.0");
        totalLabel.setFont(new Font("Arial", Font.BOLD, 16));
        totalLabel.setForeground(new Color(255, 20, 147)); 


        totalPanel.add(totalLabel);

        tablePanel.add(tableScrollPane, BorderLayout.CENTER);
        tablePanel.add(totalPanel, BorderLayout.SOUTH);

        add(tablePanel, BorderLayout.EAST);

        setVisible(true);
    }

    private void updateTotal() {
        double total = 0.0;
        for (int i = 0; i < tableModel.getRowCount(); i++) {
            String priceString = tableModel.getValueAt(i, 2).toString().replace("$", "");
            total += Double.parseDouble(priceString);
        }
        totalLabel.setText("Total: $" + total);
    }

    private JButton createButton(String text) {
        JButton button = new JButton(text);
        button.setBackground(new Color(255, 105, 180));
        button.setForeground(Color.WHITE); 
        button.setFont(new Font("Arial", Font.BOLD, 14));
        button.setFocusPainted(false);
        button.setBorder(BorderFactory.createLineBorder(Color.WHITE));
        return button;
    }
}
