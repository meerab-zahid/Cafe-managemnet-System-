package pkgnew.practic;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.border.Border;
import javax.swing.table.DefaultTableCellRenderer;

public class ItemManagement {
 ItemManagement() {
        JFrame frame = new JFrame("Item Management System");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(2000, 700);
        frame.setLayout(new BorderLayout());

                ImageIcon floralImage = new ImageIcon("C:\\Users\\hp\\Desktop\\practice\\Boarder.jpg"); 
        Border floralBorder = BorderFactory.createMatteBorder(50, 50, 80, 50, floralImage); 
        frame.getRootPane().setBorder(floralBorder); 

        
        String[] columnNames = {"Item Name", "Item ID", "Price", "Type", "Sale Quantity", "Price or Status"};
        Object[][] data = {
                {"Burger", "ID101", 100.0, "Meal", 10, "Available"},
                {"Sandwich", "ID102", 200.0, "Snacks", 5, "Sold"},
                {"Soda", "ID103", 150.0, "Drink", 8, "Available"}
        };

        DefaultTableModel tableModel = new DefaultTableModel(data, columnNames);
        JTable table = new JTable(tableModel);

        
        table.getTableHeader().setBackground(new Color(255, 182, 193)); 
        table.getTableHeader().setForeground(Color.WHITE); 
        table.getTableHeader().setFont(new Font("Arial", Font.BOLD, 14));

       
        DefaultTableCellRenderer centerRenderer = new DefaultTableCellRenderer();
        centerRenderer.setHorizontalAlignment(SwingConstants.CENTER);
        for (int i = 0; i < table.getColumnCount(); i++) {
            table.getColumnModel().getColumn(i).setCellRenderer(centerRenderer);
        }

        JScrollPane tableScrollPane = new JScrollPane(table);

        
        JPanel inputPanel = new JPanel();
        inputPanel.setLayout(new GridLayout(8, 2, 10, 10));
        inputPanel.setBackground(new Color(255, 182, 193)); 

        JLabel nameLabel = createLabel("Item Name:");
        JTextField nameField = new JTextField();

        JLabel idLabel = createLabel("Item ID:");
        JTextField idField = new JTextField();

        JLabel priceLabel = createLabel("Price:");
        JTextField priceField = new JTextField();

        JLabel typeLabel = createLabel("Type:");
        JTextField typeField = new JTextField();

        JLabel saleLabel = createLabel("Sale Quantity:");
        JTextField saleField = new JTextField();

        JLabel statusLabel = createLabel("Price or Status:");
        JTextField statusField = new JTextField();

        JButton addButton = createButton("Add");
        JButton deleteButton = createButton("Delete");
        JButton editButton = createButton("Edit");
        JButton backButton = createButton("Back");

        
        inputPanel.add(nameLabel);
        inputPanel.add(nameField);
        inputPanel.add(idLabel);
        inputPanel.add(idField);
        inputPanel.add(priceLabel);
        inputPanel.add(priceField);
        inputPanel.add(typeLabel);
        inputPanel.add(typeField);
        inputPanel.add(saleLabel);
        inputPanel.add(saleField);
        inputPanel.add(statusLabel);
        inputPanel.add(statusField);
        inputPanel.add(addButton);
        inputPanel.add(deleteButton);
        inputPanel.add(editButton);
        inputPanel.add(backButton);

        
        addButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String name = nameField.getText();
                String id = idField.getText();
                String price = priceField.getText();
                String type = typeField.getText();
                String sale = saleField.getText();
                String status = statusField.getText();

                if (!name.isEmpty() && !id.isEmpty() && !price.isEmpty() && !type.isEmpty() && !sale.isEmpty() && !status.isEmpty()) {
                    tableModel.addRow(new Object[]{name, id, Double.parseDouble(price), type, Integer.parseInt(sale), status});
                    JOptionPane.showMessageDialog(frame, "Item added successfully!");
                    nameField.setText("");
                    idField.setText("");
                    priceField.setText("");
                    typeField.setText("");
                    saleField.setText("");
                    statusField.setText("");
                } else {
                    JOptionPane.showMessageDialog(frame, "Please fill all fields.", "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        });

        deleteButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int selectedRow = table.getSelectedRow();
                if (selectedRow != -1) {
                    tableModel.removeRow(selectedRow);
                    JOptionPane.showMessageDialog(frame, "Item deleted successfully!");
                } else {
                    JOptionPane.showMessageDialog(frame, "Please select a row to delete.", "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        });

        editButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int selectedRow = table.getSelectedRow();  
        if (selectedRow != -1) {  
           
            if (!editButton.getText().equals("Save Changes")) {  
                
                nameField.setText((String) tableModel.getValueAt(selectedRow, 0));  
                idField.setText((String) tableModel.getValueAt(selectedRow, 1));  
                priceField.setText(String.valueOf(tableModel.getValueAt(selectedRow, 2)));  
                typeField.setText((String) tableModel.getValueAt(selectedRow, 3));  
                saleField.setText(String.valueOf(tableModel.getValueAt(selectedRow, 4)));  
                statusField.setText((String) tableModel.getValueAt(selectedRow, 5));  

                editButton.setText("Save Changes"); 
            } else {  
                
                tableModel.setValueAt(nameField.getText(), selectedRow, 0);  
                tableModel.setValueAt(idField.getText(), selectedRow, 1);  
                tableModel.setValueAt(Double.parseDouble(priceField.getText()), selectedRow, 2);  
                tableModel.setValueAt(typeField.getText(), selectedRow, 3);  
                tableModel.setValueAt(Integer.parseInt(saleField.getText()), selectedRow, 4);  
                tableModel.setValueAt(statusField.getText(), selectedRow, 5);  
                
                JOptionPane.showMessageDialog(frame, "Item updated successfully!");  
                
                
                editButton.setText("Update");  
                nameField.setText("");  
                idField.setText("");  
                priceField.setText("");  
                typeField.setText("");  
                saleField.setText("");  
                statusField.setText("");  
            }  
        } else {  
            JOptionPane.showMessageDialog(frame, "Please select a row to update.", "Error", JOptionPane.ERROR_MESSAGE);  
        } 
            }
        });

        backButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                frame.dispose();
                new Dashboard();
            }
        });

        
        frame.add(tableScrollPane, BorderLayout.CENTER);
        frame.add(inputPanel, BorderLayout.SOUTH);

        
        frame.getContentPane().setBackground(new Color(255, 182, 193)); 
        frame.setVisible(true);
    }

    private JLabel createLabel(String text) {
        JLabel label = new JLabel(text);
        label.setForeground(Color.WHITE);
        label.setFont(new Font("Arial", Font.BOLD, 14));
        return label;
    }

    private JButton createButton(String text) {
        JButton button = new JButton(text);
        button.setBackground(new Color(255, 105, 180)); 
        button.setForeground(Color.WHITE);
        button.setFont(new Font("Arial", Font.BOLD, 14));
        button.setFocusPainted(false);
        button.setBorder(BorderFactory.createLineBorder(Color.WHITE));
        return button;
    }
}
