
package pkgnew.practic;


public class Staff extends Person{
private String role;

    public Staff(String name, int age, String role) {
        super(name, age);
        this.role = role;
    }

    public String getRole() {
        return role;
    }

    @Override
    public void displayRole() {
        System.out.println("Staff Role: " + role);
    }
}
