package pkgnew.practic;

import java.util.List;
import java.util.ArrayList;


public class Cafe {
  private String name;
    private List<Staff> staffList;
    private Menujava menu; 

    public Cafe(String name) {
        this.name = name;
        this.staffList = new ArrayList<>();
        this.menu = new Menujava(); 
    }

    public void addStaff(Staff staff) {
        staffList.add(staff);
    }

    public void removeStaff(Staff staff) {
        staffList.remove(staff);
    }

    public Menujava getMenu() {
        return menu;
    }

    public void displayCafeDetails() {
        System.out.println("Welcome to " + name + " Cafe!");
        System.out.println("Our Staff:");
        for (Staff staff : staffList) {
            System.out.println("- " + staff.getName() + " (" + staff.getRole() + ")");
        }
        System.out.println("Our Menu:");
        menu.displayMenu();
    }

}
