package pkgnew.practic;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;

public class NewPractic {
    
    public static void main(String[] args) {
       new Login();
       Cafe cafe = new Cafe("Girls Cafe");

        
        Staff staff1 = new Staff("Meerab", 30, "Manager");
        Staff staff2 = new Staff("Fatima", 25, "Chef");
        cafe.addStaff(staff1);
        cafe.addStaff(staff2);

        
        FoodItem food1 = new FoodItem("Burger", 105.0, 500);
        DrinkItem drink1 = new DrinkItem("Coca Cola", 1.99, "Soft Drink");
        DrinkItem drink2 = new DrinkItem("Wine", 12.99, "Alcoholic");

        drink1.displayDetails(); 
        drink2.displayDetails();
        cafe.getMenu().addItem(food1);
        cafe.getMenu().addItem(drink1);

        
        cafe.displayCafeDetails();

        
        FoodItem food2 = new FoodItem("Veggie Burger", 6.49, 400);
        cafe.getMenu().updateItem(food1, food2);

        
        cafe.getMenu().deleteItem(drink1);

        
        cafe.getMenu().displayMenu();

        
        Customer customer = new Customer("Ali", 28, 101);
        Order order = new Order(1, customer);
        order.addItem(food2);
        order.displayOrder();
    }
}
