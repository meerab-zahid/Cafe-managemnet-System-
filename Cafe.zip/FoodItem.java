package pkgnew.practic;

public class FoodItem extends MenuItem{
    private int calories;

    public FoodItem(String name, double price, int calories) {
        super(name, price);
        this.calories = calories;
    }

    public int getCalories() {
        return calories;
    }

    @Override
    public void displayDetails() {
        System.out.println("Food Item: " + getName() + ", Price: $" + getPrice() + ", Calories: " + calories);
    }
}
