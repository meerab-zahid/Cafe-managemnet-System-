package pkgnew.practic;


public class DrinkItem extends MenuItem {
     private String drinkType; 

    public DrinkItem(String name, double price, String drinkType) {
        super(name, price);
        this.drinkType = drinkType;
    }

    public String getDrinkType() {
        return drinkType;
    }

    @Override
    public void displayDetails() {
        System.out.println("Drink Item: " + getName() + ", Price: $" + getPrice() + ", Type: " + drinkType);
    }
}
