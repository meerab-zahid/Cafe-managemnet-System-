
package pkgnew.practic;

import java.awt.Color;
import java.awt.Container;
import javax.swing.JFrame;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.border.Border;
public class Login {
Login()
{
     JFrame frame = new JFrame("Login Page");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(2000, 700);
        frame.setLayout(new GridLayout(3, 2, 10, 10));

        ImageIcon floralImage = new ImageIcon("C:\\Users\\hp\\Desktop\\practice\\Boarder.jpg"); 
        Border floralBorder = BorderFactory.createMatteBorder(50, 50, 50, 50, floralImage); 
        frame.getRootPane().setBorder(floralBorder); 

                      
        Container container = frame.getContentPane();
        container.setBackground(new Color(255, 182, 193));

       
        JPanel panel = new JPanel();
        panel.setLayout(new GridLayout(3, 2, 10, 10));
        panel.setBackground(new Color(255, 240, 245)); 

        
        JLabel titleLabel = new JLabel("Girls Cafe", JLabel.CENTER);
        titleLabel.setFont(new Font("Brush Script MT", Font.BOLD, 50));
        titleLabel.setForeground(new Color(255, 105, 180)); 
        frame.add(titleLabel, BorderLayout.NORTH);

        
        JLabel labelUsername = new JLabel("Username:");
        labelUsername.setFont(new Font("Arial", Font.PLAIN, 16));
        JTextField textUsername = new JTextField();
        textUsername.setFont(new Font("Arial", Font.PLAIN, 14));
        textUsername.setPreferredSize(new Dimension(200, 30));
        textUsername.setBackground(Color.WHITE);

        JLabel labelPassword = new JLabel("Password:");
        labelPassword.setFont(new Font("Arial", Font.PLAIN, 16));
        JPasswordField textPassword = new JPasswordField();
        textPassword.setFont(new Font("Arial", Font.PLAIN, 14));
        textPassword.setPreferredSize(new Dimension(200, 30)); 
        textPassword.setBackground(Color.WHITE);

        
        JButton loginButton = new JButton("Login");
        loginButton.setFont(new Font("Arial", Font.BOLD, 14));
        loginButton.setBackground(new Color(255, 105, 180));
        loginButton.setForeground(Color.WHITE);

        JButton resetButton = new JButton("Reset");
        resetButton.setFont(new Font("Arial", Font.BOLD, 14));
        resetButton.setBackground(new Color(255, 20, 147)); 
        resetButton.setForeground(Color.WHITE);

        
        panel.add(labelUsername);
        panel.add(textUsername);
        panel.add(labelPassword);
        panel.add(textPassword);
        panel.add(loginButton);
        panel.add(resetButton);

        
        frame.add(panel, BorderLayout.CENTER);

        
        loginButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String username = textUsername.getText();
                String password = new String(textPassword.getPassword());

                
                if (validate(username, password)) {
                    JOptionPane.showMessageDialog(frame, "Login successful!", "Success", JOptionPane.INFORMATION_MESSAGE);
                    frame.dispose();
                    new Dashboard();
                } else {
                    JOptionPane.showMessageDialog(frame, "Invalid username or password.", "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        });

        resetButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                textUsername.setText("");
                textPassword.setText("");
            }
        });

        frame.setVisible(true);
    }
    private static boolean validate(String username, String password) {
        boolean isValid = false;

        
        String url = "jdbc:mysql://localhost:3306/login";
        String dbUser = "root";
        String dbPassword ="";

        
        try (Connection connection = DriverManager.getConnection(url, dbUser, dbPassword);
             PreparedStatement statement = connection.prepareStatement("SELECT * FROM users WHERE username = ? AND password = ?")) {

            
            statement.setString(1, username);
            statement.setString(2, password);

            
            ResultSet resultSet = statement.executeQuery();
            if (resultSet.next()) {
                isValid = true;
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }

        return isValid;
    }
}
