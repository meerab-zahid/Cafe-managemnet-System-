package pkgnew.practic;
import javax.swing.JFrame;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.border.Border;
public class Dashboard {
        Dashboard() {
        JFrame frame = new JFrame();
        frame.setTitle("Cafe Management System - Main Dashboard");
        frame.setSize(2000, 700);
        frame.setLayout(new BorderLayout());
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
        
        ImageIcon floralImage = new ImageIcon("C:\\Users\\hp\\Desktop\\practice\\Boarder.jpg"); 
        Border floralBorder = BorderFactory.createMatteBorder(50, 50, 80, 50, floralImage); 
        frame.getRootPane().setBorder(floralBorder); 

           
        
        Container container = frame.getContentPane();
        container.setBackground(new Color(255, 182, 193)); 

        
        JLabel welcomeLabel = new JLabel("Welcome to Girls Cafe", JLabel.CENTER);
        welcomeLabel.setFont(new Font("Brush Script MT", Font.BOLD, 50)); 
        welcomeLabel.setForeground(new Color(255, 105, 180));
        frame.add(welcomeLabel, BorderLayout.NORTH); 

        
        JPanel buttonPanel = new JPanel();
        buttonPanel.setLayout(new GridLayout(2, 2, 10, 10));
        buttonPanel.setBackground(new Color(255, 105, 180)); 
        

        
        JButton hButton = createButton("Home");
        JButton mButton = createButton("Menu Item Management");
        JButton oButton = createButton("Order Management");
        JButton sButton = createButton("Staff Management");

        
        hButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                frame.dispose();
                new Login();
            }
        });

        mButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                frame.dispose();
                new ItemManagement();
            }
        });

        oButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                frame.dispose();
                new Menu();
            }
        });

        sButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                frame.dispose();
                new StaffMangement();
            }
        });

        
        buttonPanel.add(hButton);
        buttonPanel.add(mButton);
        buttonPanel.add(oButton);
        buttonPanel.add(sButton);

        
        frame.add(buttonPanel, BorderLayout.CENTER);

        

        
        frame.setVisible(true);
    }

    private JButton createButton(String text) {
        JButton button = new JButton(text);
        button.setBackground(new Color(255, 105, 180));
        button.setForeground(Color.WHITE);
        button.setFont(new Font("Arial", Font.BOLD, 14));
        button.setPreferredSize(new Dimension(150, 30)); 
        button.setFocusPainted(false);
        button.setBorder(BorderFactory.createLineBorder(Color.WHITE));
        return button;
    }
}
