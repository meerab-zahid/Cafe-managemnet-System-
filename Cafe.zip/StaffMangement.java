package pkgnew.practic;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.border.Border;

public class StaffMangement {
      private DefaultListModel<String> staffListModel;  

    public StaffMangement() {  
        
        JFrame frame = new JFrame("Cafe Management System - Staff Management");  
        frame.setSize(2000, 700);  
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);  
        frame.setLocationRelativeTo(null);  
        frame.setLayout(new BorderLayout());  

       
        ImageIcon floralImage = new ImageIcon("C:\\Users\\hp\\Desktop\\practice\\Boarder.jpg"); 
        Border floralBorder = BorderFactory.createMatteBorder(50, 50, 80, 50, floralImage); 
        frame.getRootPane().setBorder(floralBorder); 

        JPanel topPanel = new JPanel();  
        topPanel.setBackground(new Color(255, 182, 193)); 
        JLabel titleLabel = new JLabel("Staff Management");  
        titleLabel.setFont(new Font("Arial", Font.BOLD, 24));  
        titleLabel.setForeground(Color.WHITE);  
        topPanel.add(titleLabel);  
        frame.add(topPanel, BorderLayout.NORTH);  

       
        staffListModel = new DefaultListModel<>();  
        JList<String> staffList = new JList<>(staffListModel);  
        JScrollPane scrollPane = new JScrollPane(staffList);  

        
        staffListModel.addElement("Meerab - Manager - $3000");  
        staffListModel.addElement("Fatima - Barista - $2000");  
        staffListModel.addElement("Kashif - Chef - $2500");  

        
        scrollPane.setBackground(new Color(255, 192, 203));
        staffList.setBackground(new Color(255, 228, 225)); 
        staffList.setForeground(Color.BLACK); 

        frame.add(scrollPane, BorderLayout.CENTER);  

        
        JPanel buttonPanel = new JPanel();  
        buttonPanel.setLayout(new FlowLayout());  
        buttonPanel.setBackground(new Color(255, 182, 193)); 

        JButton addButton = createButton("Add Staff");  
        JButton editButton = createButton("Edit Staff");  
        JButton deleteButton = createButton("Delete Staff");  
        JButton backButton = createButton("Back");  

        buttonPanel.add(addButton);  
        buttonPanel.add(editButton);  
        buttonPanel.add(backButton);  
        buttonPanel.add(deleteButton);  

        frame.add(buttonPanel, BorderLayout.SOUTH);  

        backButton.addActionListener(new ActionListener() {  
            @Override  
            public void actionPerformed(ActionEvent e) {  
                frame.dispose();  
                new Menu(); 
            }  
        });  

       
        addButton.addActionListener(new ActionListener() {  
            @Override  
            public void actionPerformed(ActionEvent e) {  
                String newStaff = JOptionPane.showInputDialog(frame, "Enter Staff Details (Name - Role - Salary):");  
                if (newStaff != null && !newStaff.trim().isEmpty()) {  
                    staffListModel.addElement(newStaff);  
                }  
            }  
        });  

        
        editButton.addActionListener(new ActionListener() {  
            @Override  
            public void actionPerformed(ActionEvent e) {  
                if (!staffList.isSelectionEmpty()) {  
                    String selectedStaff = staffList.getSelectedValue();  
                    String updatedStaff = JOptionPane.showInputDialog(frame, "Edit Staff Details:", selectedStaff);  
                    if (updatedStaff != null && !updatedStaff.trim().isEmpty()) {  
                        int selectedIndex = staffList.getSelectedIndex();  
                        staffListModel.set(selectedIndex, updatedStaff);  
                    }  
                } else {  
                    JOptionPane.showMessageDialog(frame, "Please select a staff member to edit.");  
                }  
            }  
        });  

       
        deleteButton.addActionListener(new ActionListener() {  
            @Override  
            public void actionPerformed(ActionEvent e) {  
                if (!staffList.isSelectionEmpty()) {  
                    int confirm = JOptionPane.showConfirmDialog(frame, "Are you sure you want to delete this staff member?");  
                    if (confirm == JOptionPane.YES_OPTION) {  
                        staffListModel.remove(staffList.getSelectedIndex());  
                    }  
                } else {  
                    JOptionPane.showMessageDialog(frame, "Please select a staff member to delete.");  
                }  
            }  
        });  

        frame.setVisible(true);  
    }  

   
    private JButton createButton(String text) {  
        JButton button = new JButton(text);  
        button.setBackground(new Color(255, 105, 180)); 
        button.setForeground(Color.WHITE); 
        button.setFont(new Font("Arial", Font.BOLD, 14));  
        button.setFocusPainted(false);  
        button.setBorder(BorderFactory.createLineBorder(Color.WHITE));  
        return button;  
    }  
}
